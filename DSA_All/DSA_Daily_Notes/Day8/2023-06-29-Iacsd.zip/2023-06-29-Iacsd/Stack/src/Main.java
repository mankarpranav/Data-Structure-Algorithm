public class Main {
    public static void main(String[] args) {
        Stack<Integer>  si = new Stack<Integer>(5);
        System.out.println(si.push(10));
        System.out.println(si.push(10));
        System.out.println(si.pop());
    }
}
