import java.util.Stack;

public class LinkedList {
    private Node head;
    /*private int size = 0;
    private Node last;*/

    public LinkedList() {
        head = null;
    }

    public boolean insert(int data) {
        Node newNode = new Node(data);
        if(newNode == null) {
            return false;
        }

        if(head == null) {
            this.head = newNode;
            return true;
        }

        Node last = head;
        while(last.getNext() != null) {
            last = last.getNext();
        }

        last.setNext(newNode);
        return true;
    }

    public void display() {
        Node temp = head;
        while(temp != null) {
            System.out.print(temp.getData() + " ");
            temp = temp.getNext();
        }
        System.out.println();
    }

    public void display(Node head) {
        if(head == null) {
            return;
        }

        System.out.print(head.getData() + " ");
        display(head.getNext());
    }

    public Node getHead() {
        return head;
    }

    public void displayRev() {
        Node temp = head;
        Stack<Node> s = new Stack<>();

        while(temp != null) {
            s.push(temp);
            temp = temp.getNext();
        }

        while(!s.isEmpty()) {
            System.out.print(s.pop().getData() + " ");
        }
        System.out.println();
    }

    public void displayRev(Node head) {
        if(head == null) {
            return;
        }
        displayRev(head.getNext());
        System.out.print(head.getData()  +" ");
    }

    public boolean insert(int data, int position) {
        if(position <= 0 || (head == null && position > 1)) {
            return false;
        }

        Node newNode = new Node(data);
        if(newNode == null) {
            return false;
        }

        if( position == 1) {
            newNode.setNext(head);
            head = newNode;
            return true;
        }

        //locate prev node
        Node prev = head;
        for(int i = 1; i < position - 1; i++) {
            prev = prev.getNext();
            if(prev == null) {
                return false;
            }
        }

        newNode.setNext(prev.getNext());
        prev.setNext(newNode);

        return true;

    }
}
